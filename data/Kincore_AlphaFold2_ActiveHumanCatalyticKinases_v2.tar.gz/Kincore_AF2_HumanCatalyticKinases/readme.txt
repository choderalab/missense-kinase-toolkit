# Created by Bulat Faezov and Roland Dunbrack
# Fox Chase Cancer Center
# Contact: Bulat.Faezov@fccc.edu, Roland.Dunbrack@fccc.edu
# v1. July 22, 2023
# v2. August 6, 2023
# Please cite biorxiv paper: Faezov and Dunbrack, 2023
# This is version 2. A few filenames were changed because they had an extraneous "_e_" due to an editing error. No coordinates have been changed.

This directory contains models of all 437 catalytic typical human kinases (those with a fold similar to PKA) made with AlphaFold2.
Each filename contains the following information.

For example, AGC_AKT2_91.01_activeAF2_20MSA_family_model1.cif:

Family name: AGC
Gene name (HUGO): AKT2
Minimum value of pLDDT across activation loopo residues: 91.01
Template source: ActiveAF2 [these are distillation models made with AlphaFold2;
     other sources: ActivePDB = active structures in PDB; PDB70, or "notemp" for no template
Size of MSA: 20MSA [number of sequences in MSA input to AlphaFold2]
Source of MSA sequences: family [family = human kinases in same kinase family, in this case AGC;
     other sources: "ortholog" means kinases from Uniprot with >50% seqid and mutually <90% seqid to each other; or uniref90]
Model number from AlphaFold2: model1
